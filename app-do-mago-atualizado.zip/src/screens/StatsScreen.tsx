// Tela de Estatísticas Avançadas
import React from "react";
import { View, Text, ScrollView, Pressable } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { RootStackParamList } from "../navigation/RootNavigator";
import { useStatsStore } from "../state/statsStore";
import { useBankrollStore } from "../state/bankrollStore";

type StatsScreenProps = {
  navigation: NativeStackNavigationProp<RootStackParamList, "Stats">;
};

const StatsScreen: React.FC<StatsScreenProps> = ({ navigation }) => {
  const { stats, userLevel, xp, getWinRate, achievements } = useStatsStore();
  const { dailyResults } = useBankrollStore();

  const winRate = getWinRate();
  const xpForNextLevel = ((userLevel) * 100) - xp;
  const unlockedAchievements = achievements.filter(a => a.unlocked);
  const nextAchievement = achievements.find(a => !a.unlocked);

  // Calcula melhor horário baseado em lucro
  const calculateBestLive = () => {
    const liveStats: { [key: string]: { profit: number; count: number } } = {};

    dailyResults.forEach((day) => {
      day.lives.forEach((live) => {
        if (!liveStats[live.time]) {
          liveStats[live.time] = { profit: 0, count: 0 };
        }
        liveStats[live.time].profit += live.profit;
        liveStats[live.time].count += 1;
      });
    });

    let bestLive = "Sem dados";
    let bestAvg = -Infinity;

    Object.keys(liveStats).forEach((time) => {
      const avg = liveStats[time].profit / liveStats[time].count;
      if (avg > bestAvg) {
        bestAvg = avg;
        bestLive = time;
      }
    });

    return { bestLive, avgProfit: bestAvg };
  };

  const { bestLive, avgProfit } = calculateBestLive();

  // Calcula performance semanal
  const lastWeekResults = dailyResults.slice(-7);
  const weeklyProfit = lastWeekResults.reduce((sum, day) => sum + day.totalProfit, 0);
  const profitableDays = lastWeekResults.filter((day) => day.totalProfit > 0).length;

  return (
    <View className="flex-1 bg-slate-950">
      <LinearGradient colors={["#0f172a", "#1e293b"]} style={{ flex: 1 }}>
        <SafeAreaView className="flex-1">
          <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
            {/* Header */}
            <View className="px-6 pt-4 pb-6">
              <View className="flex-row items-center justify-between mb-6">
                <Pressable
                  onPress={() => navigation.goBack()}
                  className="w-12 h-12 bg-slate-800 rounded-full items-center justify-center active:opacity-70"
                >
                  <Ionicons name="arrow-back" size={24} color="white" />
                </Pressable>
                <Text className="text-white text-2xl font-bold">Estatísticas</Text>
                <Pressable
                  onPress={() => navigation.navigate("Achievements")}
                  className="w-12 h-12 bg-purple-600 rounded-full items-center justify-center active:opacity-70"
                >
                  <Ionicons name="trophy" size={24} color="white" />
                </Pressable>
              </View>

              {/* Nível e XP - DESTAQUE MAIOR */}
              <View className="bg-gradient-to-br from-purple-600 to-purple-800 rounded-3xl p-6 mb-6 border-4 border-yellow-400">
                <View className="flex-row items-center justify-between mb-4">
                  <View className="flex-1">
                    <Text className="text-purple-200 text-sm font-semibold mb-1">Seu Nível</Text>
                    <Text className="text-white text-5xl font-black mb-2">
                      Nível {userLevel}
                    </Text>
                    <View className="flex-row items-center">
                      <Ionicons name="flame" size={20} color="#fbbf24" />
                      <Text className="text-yellow-300 text-base font-bold ml-2">
                        {xp} XP Total
                      </Text>
                    </View>
                  </View>
                  <View className="w-24 h-24 bg-gradient-to-br from-yellow-400 to-yellow-500 rounded-full items-center justify-center border-4 border-yellow-300">
                    <Ionicons name="star" size={48} color="white" />
                  </View>
                </View>
                <View className="bg-purple-900/50 rounded-full h-4 mb-2 overflow-hidden">
                  <View
                    className="bg-gradient-to-r from-yellow-400 to-yellow-500 h-4 rounded-full"
                    style={{
                      width: `${((xp % 100) / 100) * 100}%`,
                    }}
                  />
                </View>
                <Text className="text-purple-200 text-sm font-semibold text-center">
                  {xpForNextLevel} XP para o próximo nível
                </Text>
              </View>

              {/* Taxa de Acerto */}
              {stats.followedEntries > 0 && (
                <View className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-3xl p-6 mb-6 border-2 border-slate-700">
                  <View className="flex-row items-center mb-4">
                    <View className="w-12 h-12 bg-green-500 rounded-2xl items-center justify-center mr-3">
                      <Ionicons name="analytics" size={28} color="white" />
                    </View>
                    <Text className="text-white font-black text-2xl">
                      Taxa de Acerto
                    </Text>
                  </View>

                  <View className="items-center mb-4">
                    <Text className="text-6xl font-black text-white mb-2">
                      {winRate.toFixed(1)}%
                    </Text>
                    <Text className="text-slate-400 text-base">
                      {stats.wins} vitórias de {stats.followedEntries} entradas
                    </Text>
                  </View>

                  <View className="flex-row justify-around pt-4 border-t border-slate-700">
                    <View className="items-center">
                      <View className="w-12 h-12 bg-green-500/20 rounded-xl items-center justify-center mb-2">
                        <Ionicons name="checkmark-circle" size={28} color="#22c55e" />
                      </View>
                      <Text className="text-green-400 text-2xl font-bold">
                        {stats.wins}
                      </Text>
                      <Text className="text-slate-400 text-sm">Wins</Text>
                    </View>
                    <View className="items-center">
                      <View className="w-12 h-12 bg-red-500/20 rounded-xl items-center justify-center mb-2">
                        <Ionicons name="close-circle" size={28} color="#ef4444" />
                      </View>
                      <Text className="text-red-400 text-2xl font-bold">
                        {stats.losses}
                      </Text>
                      <Text className="text-slate-400 text-sm">Losses</Text>
                    </View>
                    <View className="items-center">
                      <View className="w-12 h-12 bg-purple-500/20 rounded-xl items-center justify-center mb-2">
                        <Ionicons name="trending-up" size={28} color="#a855f7" />
                      </View>
                      <Text className="text-purple-400 text-2xl font-bold">
                        {stats.totalProfit >= 0 ? "+" : ""}
                        {stats.totalProfit.toFixed(0)}
                      </Text>
                      <Text className="text-slate-400 text-sm">Lucro Total</Text>
                    </View>
                  </View>
                </View>
              )}

              {/* Melhor Horário */}
              {bestLive !== "Sem dados" && (
                <View className="bg-gradient-to-br from-blue-900/40 to-blue-800/40 rounded-3xl p-6 mb-6 border-2 border-blue-500/50">
                  <View className="flex-row items-center mb-4">
                    <View className="w-12 h-12 bg-blue-500 rounded-2xl items-center justify-center mr-3">
                      <Ionicons name="time" size={28} color="white" />
                    </View>
                    <Text className="text-white font-black text-xl">
                      Melhor Horário
                    </Text>
                  </View>
                  <View className="items-center">
                    <Text className="text-5xl font-black text-white mb-2">
                      {bestLive}
                    </Text>
                    <Text className="text-blue-300 text-base">
                      Lucro médio: R$ {avgProfit.toFixed(2)}
                    </Text>
                  </View>
                </View>
              )}

              {/* Performance Semanal */}
              <View className="bg-gradient-to-br from-yellow-900/40 to-yellow-800/40 rounded-3xl p-6 mb-6 border-2 border-yellow-500/50">
                <View className="flex-row items-center mb-4">
                  <View className="w-12 h-12 bg-yellow-500 rounded-2xl items-center justify-center mr-3">
                    <Ionicons name="calendar" size={28} color="white" />
                  </View>
                  <Text className="text-white font-black text-xl">
                    Últimos 7 Dias
                  </Text>
                </View>
                <View className="flex-row justify-around">
                  <View className="items-center">
                    <Text className="text-white text-3xl font-bold mb-1">
                      {profitableDays}/7
                    </Text>
                    <Text className="text-yellow-300 text-sm">Dias Lucrativos</Text>
                  </View>
                  <View className="items-center">
                    <Text className={`text-3xl font-bold mb-1 ${weeklyProfit >= 0 ? "text-green-400" : "text-red-400"}`}>
                      {weeklyProfit >= 0 ? "+" : ""}R${weeklyProfit.toFixed(2)}
                    </Text>
                    <Text className="text-yellow-300 text-sm">Lucro Semanal</Text>
                  </View>
                </View>
              </View>

              {/* Sequência Atual */}
              <View className="bg-gradient-to-br from-purple-900/40 to-purple-800/40 rounded-3xl p-6 mb-6 border-2 border-purple-500/40">
                <View className="flex-row items-center mb-4">
                  <View className="w-12 h-12 bg-purple-500 rounded-2xl items-center justify-center mr-3">
                    <Ionicons name="flame" size={28} color="white" />
                  </View>
                  <Text className="text-white font-black text-xl">
                    Sequência de Uso
                  </Text>
                </View>
                <View className="items-center">
                  <Text className="text-5xl font-black text-white mb-2">
                    {stats.currentStreak} dias
                  </Text>
                  <Text className="text-purple-300 text-base">
                    Continue assim! 🔥
                  </Text>
                </View>
              </View>

              {/* Conquistas Recentes - GAMIFICAÇÃO */}
              {unlockedAchievements.length > 0 && (
                <View className="bg-gradient-to-r from-orange-900/40 to-orange-800/40 rounded-3xl p-6 mb-6 border-2 border-orange-500/50">
                  <View className="flex-row items-center justify-between mb-4">
                    <View className="flex-row items-center">
                      <View className="w-12 h-12 bg-orange-500 rounded-2xl items-center justify-center mr-3">
                        <Ionicons name="ribbon" size={28} color="white" />
                      </View>
                      <Text className="text-white font-black text-xl">
                        Conquistas
                      </Text>
                    </View>
                    <Pressable
                      onPress={() => navigation.navigate("Achievements")}
                      className="bg-orange-500 px-4 py-2 rounded-xl active:opacity-80"
                    >
                      <Text className="text-white font-bold text-sm">Ver Todas</Text>
                    </Pressable>
                  </View>
                  <Text className="text-orange-200 text-base font-semibold mb-3">
                    {unlockedAchievements.length} de 7 desbloqueadas
                  </Text>
                  <View className="bg-slate-900/50 rounded-full h-3 mb-4 overflow-hidden">
                    <View
                      className="bg-gradient-to-r from-orange-400 to-orange-500 h-3 rounded-full"
                      style={{ width: `${(unlockedAchievements.length / 7) * 100}%` }}
                    />
                  </View>
                  {nextAchievement && (
                    <View className="bg-orange-500/20 rounded-2xl p-4">
                      <Text className="text-orange-100 text-sm font-semibold mb-1">
                        🎯 Próxima Conquista:
                      </Text>
                      <Text className="text-white text-base font-bold">
                        {nextAchievement.title}
                      </Text>
                      <Text className="text-orange-200 text-sm">
                        {nextAchievement.description}
                      </Text>
                    </View>
                  )}
                </View>
              )}

              {/* Card Motivacional */}
              <View className="bg-gradient-to-r from-green-900/40 to-green-800/40 rounded-3xl p-6 border-2 border-green-500/50">
                <View className="flex-row items-center mb-4">
                  <View className="w-12 h-12 bg-green-500 rounded-2xl items-center justify-center mr-3">
                    <Ionicons name="sparkles" size={28} color="white" />
                  </View>
                  <Text className="text-white font-black text-xl">
                    Continue Evoluindo!
                  </Text>
                </View>
                <Text className="text-green-100 text-base leading-6 font-medium">
                  {stats.totalAnalyses < 10
                    ? "Você está no caminho certo! Continue fazendo análises para desbloquear mais conquistas."
                    : stats.totalAnalyses < 50
                    ? "Ótimo progresso! Você já domina o básico. Continue assim para se tornar um Mago Experiente!"
                    : "Incrível! Você é um verdadeiro mestre dos padrões. Continue sua jornada rumo ao topo! 🚀"}
                </Text>
              </View>
            </View>
          </ScrollView>
        </SafeAreaView>
      </LinearGradient>
    </View>
  );
};

export default StatsScreen;
